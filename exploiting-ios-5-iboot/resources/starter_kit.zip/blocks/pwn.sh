#!/bin/bash

dd if=/block_0 of=/dev/rdisk0s1s3 bs=8192
dd if=/block_1029 of=/dev/rdisk0s1s3 bs=8192 seek=1029
dd if=/block_2053 of=/dev/rdisk0s1s3 bs=8192 seek=2053
dd if=/block_2314 of=/dev/rdisk0s1s3 bs=8192 seek=2314
